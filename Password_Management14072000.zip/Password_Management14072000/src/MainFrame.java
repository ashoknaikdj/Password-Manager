import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class MainFrame extends JFrame {
    private SecretKey secretKey;
    private Map<String, String> passwordStore = new HashMap<>();
    private String loggedInUserPassword;

    private JTextField labelField;
    private JPasswordField passwordEntryField;
    private JTextField retrieveLabelField;
    private JLabel generatedPasswordLabel;
    private JTextArea passwordsDisplayArea;

    public MainFrame(SecretKey secretKey, String loggedInUserPassword) {
        this.secretKey = secretKey;
        this.loggedInUserPassword = loggedInUserPassword;

        setTitle("Password Manager");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        mainPanel.add(new JLabel("Password Manager"), gbc);

        gbc.gridy = 1;
        gbc.gridwidth = 1;
        mainPanel.add(new JLabel("Label:"), gbc);

        gbc.gridx = 1;
        labelField = new JTextField(20);
        mainPanel.add(labelField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        mainPanel.add(new JLabel("Password:"), gbc);

        gbc.gridx = 1;
        passwordEntryField = new JPasswordField(20);
        mainPanel.add(passwordEntryField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        JButton storeButton = new JButton("Store Password");
        mainPanel.add(storeButton, gbc);
        storeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                storePassword();
            }
        });

        gbc.gridy = 4;
        mainPanel.add(new JLabel("Retrieve Password by Label:"), gbc);

        gbc.gridy = 5;
        retrieveLabelField = new JTextField(20);
        mainPanel.add(retrieveLabelField, gbc);

        gbc.gridy = 6;
        JButton retrieveButton = new JButton("Retrieve Password");
        mainPanel.add(retrieveButton, gbc);
        retrieveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                retrievePassword();
            }
        });

        // Password Generation Feature
        gbc.gridy = 7;
        gbc.gridwidth = 1;
        mainPanel.add(new JLabel("Generate Password:"), gbc);

        gbc.gridx = 1;
        JTextField lengthField = new JTextField(10);
        mainPanel.add(lengthField, gbc);

        gbc.gridy = 8;
        gbc.gridx = 0;
        JCheckBox includeUppercase = new JCheckBox("Include Uppercase");
        mainPanel.add(includeUppercase, gbc);

        gbc.gridx = 1;
        JCheckBox includeLowercase = new JCheckBox("Include Lowercase");
        mainPanel.add(includeLowercase, gbc);

        gbc.gridy = 9;
        gbc.gridx = 0;
        JCheckBox includeDigits = new JCheckBox("Include Digits");
        mainPanel.add(includeDigits, gbc);

        gbc.gridx = 1;
        JCheckBox includeSpecial = new JCheckBox("Include Special Characters");
        mainPanel.add(includeSpecial, gbc);

        gbc.gridy = 10;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        JButton generatePasswordButton = new JButton("Generate Password");
        mainPanel.add(generatePasswordButton, gbc);
        generatePasswordButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Validate length input
                    int length;
                    try {
                        length = Integer.parseInt(lengthField.getText());
                        if (length <= 0) {
                            throw new NumberFormatException("Length must be a positive integer.");
                        }
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(MainFrame.this, "Invalid length. Please enter a positive integer.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    // Generate password with selected criteria
                    boolean uppercase = includeUppercase.isSelected();
                    boolean lowercase = includeLowercase.isSelected();
                    boolean digits = includeDigits.isSelected();
                    boolean special = includeSpecial.isSelected();

                    if (!uppercase && !lowercase && !digits && !special) {
                        JOptionPane.showMessageDialog(MainFrame.this, "Please select at least one character type.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    String generatedPassword = generatePassword(length, uppercase, lowercase, digits, special);
                    passwordEntryField.setText(generatedPassword);
                    generatedPasswordLabel.setText("Generated Password: " + generatedPassword);
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(MainFrame.this, "Error generating password: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        gbc.gridy = 11;
        generatedPasswordLabel = new JLabel("Generated Password:");
        mainPanel.add(generatedPasswordLabel, gbc);

        add(mainPanel);
    }

    private void storePassword() {
        String label = labelField.getText();
        String password = new String(passwordEntryField.getPassword());

        if (!label.isEmpty() && !password.isEmpty()) {
            try {
                String encryptedPassword = encryptPassword(password);
                passwordStore.put(label, encryptedPassword);
                JOptionPane.showMessageDialog(this, "Password stored successfully!");
                labelField.setText("");
                passwordEntryField.setText("");
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error storing password");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please enter a label and password");
        }
    }

    private void retrievePassword() {
        String label = retrieveLabelField.getText();
        if (passwordStore.containsKey(label)) {
            String enteredPassword = JOptionPane.showInputDialog(this, "Enter your registered password to retrieve:");
            if (enteredPassword != null && !enteredPassword.isEmpty()) {
                if (enteredPassword.equals(loggedInUserPassword)) {
                    try {
                        String encryptedPassword = passwordStore.get(label);
                        String decryptedPassword = decryptPassword(encryptedPassword);
                        JOptionPane.showMessageDialog(this, "Password for " + label + ": " + decryptedPassword);
                    } catch (Exception e) {
                        e.printStackTrace();
                        JOptionPane.showMessageDialog(this, "Error retrieving password");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid registered password");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Password cannot be empty");
            }
        } else {
            JOptionPane.showMessageDialog(this, "No password stored for that label");
        }
    }

    private String encryptPassword(String password) throws Exception {
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, secretKey);
        byte[] encryptedBytes = cipher.doFinal(password.getBytes());
        return Base64.getEncoder().encodeToString(encryptedBytes);
    }

    private String decryptPassword(String encryptedPassword) throws Exception {
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, secretKey);
        byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(encryptedPassword));
        return new String(decryptedBytes);
    }

    private String generatePassword(int length, boolean uppercase, boolean lowercase, boolean digits, boolean special) {
        StringBuilder password = new StringBuilder();
        String upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String lower = "abcdefghijklmnopqrstuvwxyz";
        String digit = "0123456789";
        String specialChars = "!@#$%^&*()_+";

        StringBuilder characterPool = new StringBuilder();
        if (uppercase) characterPool.append(upper);
        if (lowercase) characterPool.append(lower);
        if (digits) characterPool.append(digit);
        if (special) characterPool.append(specialChars);

        Random random = new SecureRandom();
        for (int i = 0; i < length; i++) {
            int index = random.nextInt(characterPool.length());
            password.append(characterPool.charAt(index));
        }

        return password.toString();
    }

   // public static void main(String[] args) {
        // This should be invoked from AuthFrame after login
    }

