import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

public class AuthFrame extends JFrame {
    private static final String MASTER_USERNAME = "admin";
    private static final String MASTER_PASSWORD = "admin";
    private SecretKey secretKey;
    private Map<String, String> userStore = new HashMap<>();

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JTextField registerUsernameField;
    private JPasswordField registerPasswordField;

    private CardLayout cardLayout;
    private JPanel mainPanel;

    public AuthFrame() {
        setTitle("Authentication");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Generate encryption key from master password
        try {
            secretKey = generateKey(MASTER_PASSWORD);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Card Layout for switching between login and registration panels
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        // Login Panel
        JPanel loginPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        loginPanel.add(new JLabel("Login"), gbc);

        gbc.gridy = 1;
        gbc.gridwidth = 1;
        loginPanel.add(new JLabel("Username:"), gbc);

        gbc.gridx = 1;
        usernameField = new JTextField(20);
        loginPanel.add(usernameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        loginPanel.add(new JLabel("Password:"), gbc);

        gbc.gridx = 1;
        passwordField = new JPasswordField(20);
        loginPanel.add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        JButton loginButton = new JButton("Login");
        loginButton.setBackground(Color.GREEN);
        loginButton.setForeground(Color.WHITE);
        loginPanel.add(loginButton, gbc);
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });

        gbc.gridy = 4;
        JButton switchToRegisterButton = new JButton("Go to Register");
        loginPanel.add(switchToRegisterButton, gbc);
        switchToRegisterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(mainPanel, "register");
            }
        });

        // Registration Panel
        JPanel registerPanel = new JPanel(new GridBagLayout());
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        registerPanel.add(new JLabel("Register"), gbc);

        gbc.gridy = 1;
        gbc.gridwidth = 1;
        registerPanel.add(new JLabel("Username:"), gbc);

        gbc.gridx = 1;
        registerUsernameField = new JTextField(20);
        registerPanel.add(registerUsernameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        registerPanel.add(new JLabel("Password:"), gbc);

        gbc.gridx = 1;
        registerPasswordField = new JPasswordField(20);
        registerPanel.add(registerPasswordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        JButton registerButton = new JButton("Register");
        registerButton.setBackground(Color.BLUE);
        registerButton.setForeground(Color.WHITE);
        registerPanel.add(registerButton, gbc);
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                register();
            }
        });

        gbc.gridy = 4;
        JButton switchToLoginButton = new JButton("Go to Login");
        registerPanel.add(switchToLoginButton, gbc);
        switchToLoginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(mainPanel, "login");
            }
        });

        // Add panels to main panel
        mainPanel.add(loginPanel, "login");
        mainPanel.add(registerPanel, "register");
        cardLayout.show(mainPanel, "login");

        add(mainPanel);
    }

    private void login() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        try {
            if (MASTER_USERNAME.equals(username) && MASTER_PASSWORD.equals(password)) {
                JOptionPane.showMessageDialog(this, "Login successful!");
                dispose();
                new MainFrame(secretKey, password).setVisible(true); // Pass logged-in password to MainFrame
            } else if (userStore.containsKey(username) && userStore.get(username).equals(encryptPassword(password))) {
                JOptionPane.showMessageDialog(this, "Login successful!");
                dispose();
                new MainFrame(secretKey, password).setVisible(true); // Pass logged-in password to MainFrame
            } else {
                JOptionPane.showMessageDialog(this, "Invalid username or password");
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error during login");
        }
    }

    private void register() {
        String username = registerUsernameField.getText();
        String password = new String(registerPasswordField.getPassword());
        if (!username.isEmpty() && !password.isEmpty()) {
            try {
                String encryptedPassword = encryptPassword(password);
                userStore.put(username, encryptedPassword);
                JOptionPane.showMessageDialog(this, "User registered successfully!");
                clearRegisterFields();
                cardLayout.show(mainPanel, "login");
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error registering user");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please enter both username and password");
        }
    }

    private SecretKey generateKey(String password) throws Exception {
        byte[] salt = new byte[16];
        SecureRandom random = new SecureRandom();
        random.nextBytes(salt);

        KeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 65536, 256);
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        byte[] keyBytes = factory.generateSecret(spec).getEncoded();
        return new SecretKeySpec(keyBytes, "AES");
    }

    private String encryptPassword(String password) throws Exception {
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, secretKey);
        byte[] encryptedBytes = cipher.doFinal(password.getBytes());
        return Base64.getEncoder().encodeToString(encryptedBytes);
    }

    private void clearRegisterFields() {
        registerUsernameField.setText("");
        registerPasswordField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new AuthFrame().setVisible(true);
            }
        });
    }
}




